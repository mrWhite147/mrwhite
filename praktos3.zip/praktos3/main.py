from store import Store
from user import User, Admin
from auth import authenticate


if __name__ == "__main__":
    # Загрузка данных
    store = Store()
    store.load_products("products.txt")

    users = User.load_users_data("users.txt")

    admin = Admin("admin", "admin")
    admin.save_user_data("users.txt")
    users.append(admin)

    user = User("user", "user", "user")
    user.save_user_data("users.txt")
    
    users.append(user)
    while True:
        user = authenticate(users)
        if user:
            if user.role == "admin":
                admin = Admin(user.username, user.password)
                admin.manage_store(store)
            else:
                while True:
                    print("\nМеню пользователя:")
                    print("1. Просмотреть каталог товаров")
                    print("2. Добавить товар в корзину")
                    print("3. Просмотреть корзину")
                    print("4. Оформить заказ")
                    print("5. Выйти")
                    choice = input("Выберите действие: ")

                    if choice == "1":
                        for i, product in enumerate(store.products, 1):
                            print(f"{i}. {product.name}: Цена - {product.price}, Количество - {product.quantity}")
                    elif choice == "2":
                        index = int(input("Введите номер товара: ")) - 1
                        if 0 <= index < len(store.products):
                            user.add_to_cart(store.products[index])
                        else:
                            print("Неверный номер товара.")
                    elif choice == "3":
                        user.view_cart()
                    elif choice == "4":
                        user.checkout()
                    elif choice == "5":
                        break
                    else:
                        print("Неверный выбор.")

            # Сохранение данных
            store.save_products("products.txt")
            with open("users.txt", "w") as f:  # Перезаписываем файл пользователей
                for u in users:
                    u.save_user_data("users.txt")
        else:
            print("Авторизация не удалась.")

        another_session = input("Хотите войти снова? (да/нет): ")
        if another_session.lower() != "да":
            break