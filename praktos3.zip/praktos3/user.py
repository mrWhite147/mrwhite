from product_module import Product


class User:
    def __init__(self, username, password, role):
        self.username = username
        self.password = password
        self.role = role
        self.history = []
        self.cart = []

    def add_to_cart(self, product):
        if product.quantity > 0:
            self.cart.append(product)
            product.decrease_quantity()
            print(f"Товар '{product.name}' добавлен в корзину.")
        else:
            print("Товар закончился.")

    def view_cart(self):
        if not self.cart:
            print("Корзина пуста.")
            return
        total = 0
        for product in self.cart:
            print(f"{product.name}: Цена - {product.price}")
            total += product.price
        print(f"Итоговая стоимость: {total}")

    def checkout(self):
        if not self.cart:
            print("Корзина пуста.")
            return
        total = sum(product.price for product in self.cart)
        self.history.append({'items': [p.name for p in self.cart], 'total': total})
        self.cart.clear()
        print(f"Заказ оформлен. Итоговая сумма: {total}")

    def save_user_data(self, filename="C:\\Users\\vanya\\OneDrive\\Рабочий стол\\python\\praktos3\\users.txt"):
        with open(filename, "a") as f:
            cart_items = ";".join([f"{p.name}:{p.price}" for p in self.cart])
            history_items = "|".join([f"{','.join(items)}:{total}" for item in self.history for items, total in [(item['items'], item['total'])]])
            line = f"{self.username};{self.password};{self.role};{history_items};{cart_items}\n"
            f.write(line)

    @staticmethod
    def load_users_data(filename="C:\\Users\\vanya\\OneDrive\\Рабочий стол\\python\\praktos3\\users.txt"):
        users = []
        try:
            with open(filename, "r") as f:
                for line in f:
                    parts = line.strip().split(";")
                    username, password, role = parts[:3]
                    history = []
                    cart = []
                    if len(parts) > 3:
                        history_items = parts[3].split("|") if parts[3] else []
                        for item in history_items:
                            items, total = item.split(":")
                            history.append({'items': items.split(","), 'total': float(total)})
                    if len(parts) > 4:
                        cart_items = parts[4].split(";") if parts[4] else []
                        for item in cart_items:
                            name, price = item.split(":")
                            cart.append(Product(name, float(price), "", 0))  # Категория и количество не важны
                    user = User(username, password, role)
                    user.history = history
                    user.cart = cart
                    users.append(user)
            return users
        except FileNotFoundError:
            return []


class Admin(User):
    def __init__(self, username, password):
        super().__init__(username, password, "admin")

    def manage_store(self, store):
        while True:
            print("\nМеню администратора:")
            print("1. Добавить товар")
            print("2. Удалить товар")
            print("3. Изменить количество товара")
            print("4. Посмотреть каталог товаров")
            print("5. Выйти")
            choice = input("Выберите действие: ")

            if choice == "1":
                name = input("Название: ")
                price = float(input("Цена: "))
                category = input("Категория: ")
                quantity = int(input("Количество: "))
                store.add_product(Product(name, price, category, quantity))
            elif choice == "2":
                name = input("Введите название товара для удаления: ")
                store.delete_product(name)
            elif choice == "3":
                name = input("Введите название товара: ")
                quantity = int(input("Введите новое количество: "))
                store.change_product_quantity(name, quantity)
            elif choice == "4":
                for i, product in enumerate(store.products, 1):
                            print(f"{i}. {product.name}: Цена - {product.price}, Количество - {product.quantity}")
            elif choice == "5":
                break;
            else:
                print("Неверный выбор.")