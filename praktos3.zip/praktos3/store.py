from product_module import Product


class Store:
    def __init__(self):
        self.products = []

    def add_product(self, product):
        self.products.append(product)
        print(f"Товар '{product.name}' добавлен.")

    def delete_product(self, product_name):
        for product in self.products:
            if product.name == product_name:
                self.products.remove(product)
                print(f"Товар '{product_name}' удален.")
                return
        print("Товар не найден.")

    def change_product_quantity(self, product_name, new_quantity):
        for product in self.products:
            if product.name == product_name:
                product.quantity = new_quantity
                print(f"Количество товара '{product_name}' изменено на {new_quantity}.")
                return
        print("Товар не найден.")

    def filter_by_category(self, category):
        return [p for p in self.products if p.category == category]

    def save_products(self, filename="C:\\Users\\vanya\\OneDrive\\Рабочий стол\\python\\praktos3\\products.txt"):
        with open(filename, "w") as f:
            for product in self.products:
                line = f"{product.name};{product.price};{product.category};{product.quantity}\n"
                f.write(line)

    def load_products(self, filename="C:\\Users\\vanya\\OneDrive\\Рабочий стол\\python\\praktos3\\products.txt"):
        self.products = []
        try:
            with open(filename, "r") as f:
                for line in f:
                    name, price, category, quantity = line.strip().split(";")
                    self.products.append(Product(name, float(price), category, int(quantity)))
        except FileNotFoundError:
            pass