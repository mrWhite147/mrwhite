class Product:
    def __init__(self, name, price, category, quantity):
        self.name = name
        self.price = price
        self.category = category
        self.quantity = quantity

    def decrease_quantity(self):
        if self.quantity > 0:
            self.quantity -= 1

    def increase_quantity(self, amount):
        self.quantity += amount