from user import User


def authenticate(users):
    print("Добро пожаловать в Магазинчик!")
    username = input("Логин: ")
    password = input("Пароль: ")
    for user in users:
        if user.username == username and user.password == password:
            return user
    print("Неверный логин или пароль.")
    return None